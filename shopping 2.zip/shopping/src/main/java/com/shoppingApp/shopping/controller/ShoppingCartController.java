package com.shoppingApp.shopping.controller;

import com.shoppingApp.shopping.model.Order;
import com.shoppingApp.shopping.service.ShoppingCartService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/product")
public class ShoppingCartController {

    @Autowired
    ShoppingCartService shoppingCartService;

    @PostMapping("/add")
    public Double OrderStatus(@RequestBody Order order){

        return shoppingCartService.calculate(order);

    }


}
